# AI English Buddy (Android)

Voice-only English teacher. English only. Works offline.

## Get the APK (no Android Studio needed)
1. Create an empty repo on github.com (name: AIEnglishBuddy). Do NOT add README.
2. In this folder run: `./setup_github.sh https://github.com/YOUR_NAME/AIEnglishBuddy.git`
3. GitHub > Actions > "Build APK" > open the run > download **AIEnglishBuddy-debug-apk**.
4. Unzip, copy app-debug.apk to your phone, install.

## Or use Android Studio
Open this folder > let Gradle sync > Run.

## IMPORTANT for offline mode
On the phone: Settings > Google (or Speech services) > Offline speech recognition > download **English**.
Also install an English voice in Text-to-speech settings (offline voice).

## What is done
Mic button + 30 min timer, voice loop (listen, speak), grammar correction + repeat + create-own-sentence,
mistake memory, hard questions come back, level goes up/down, different topics every day, local storage,
auto sync worker when internet returns (set TOPICS_URL in app/build.gradle.kts).

## Next steps (not done yet)
- Real offline AI model (llama.cpp / MediaPipe LLM) in Teacher.kt for free conversation
- Vosk for guaranteed offline recognition and word-level pronunciation scoring
- Server for progress sync
- More questions (add JSON at TOPICS_URL: id, topic, level, prompt, explain, example, easy, alt)
