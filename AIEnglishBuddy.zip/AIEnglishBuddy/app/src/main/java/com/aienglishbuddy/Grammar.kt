package com.aienglishbuddy

object Grammar {
    data class Issue(val key: String, val why: String, val fixed: String)

    private val irregular = mapOf("goed" to "went", "eated" to "ate", "buyed" to "bought", "runned" to "ran", "comed" to "came", "seed" to "saw")
    private val ic = RegexOption.IGNORE_CASE

    fun check(text: String): Issue? {
        val t = text.trim()
        Regex("\\b(he|she|it) (go|eat|play|like|work|live|want|have|do|need|watch|study|use)\\b", ic).find(t)?.let { m ->
            val v = m.groupValues[2].lowercase()
            val s = when (v) { "go" -> "goes"; "have" -> "has"; "do" -> "does"; "study" -> "studies"; "watch" -> "watches"; else -> v + "s" }
            return Issue("verb-s", "With he, she or it, the verb needs s at the end.", t.replaceRange(m.range, "${m.groupValues[1]} $s"))
        }
        Regex("\\bi (is|are)\\b", ic).find(t)?.let { m ->
            return Issue("be-verb", "After I, we say am.", t.replaceRange(m.range, "I am"))
        }
        Regex("\\b(he|she|it) (are|am)\\b", ic).find(t)?.let { m ->
            return Issue("be-verb", "After he, she or it, we say is.", t.replaceRange(m.range, "${m.groupValues[1]} is"))
        }
        Regex("\\b(goed|eated|buyed|runned|comed|seed)\\b", ic).find(t)?.let { m ->
            return Issue("irregular-past", "This verb is irregular in the past.", t.replaceRange(m.range, irregular[m.value.lowercase()]!!))
        }
        Regex("\\bi am agree\\b", ic).find(t)?.let { m ->
            return Issue("agree", "We do not say am before agree.", t.replaceRange(m.range, "I agree"))
        }
        Regex("\\bmore better\\b", ic).find(t)?.let { m ->
            return Issue("comparative", "Better is already comparative. Do not add more.", t.replaceRange(m.range, "better"))
        }
        Regex("\\b(he|she) don't\\b", ic).find(t)?.let { m ->
            return Issue("does-not", "With he or she, we say doesn't.", t.replaceRange(m.range, "${m.groupValues[1]} doesn't"))
        }
        return null
    }
}
