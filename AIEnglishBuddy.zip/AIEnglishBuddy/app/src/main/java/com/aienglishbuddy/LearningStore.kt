package com.aienglishbuddy

import android.content.Context
import org.json.JSONObject

/** All learning data lives on the phone (SharedPreferences) so it survives closing the app and works offline. */
class LearningStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("buddy", Context.MODE_PRIVATE)
    private val d = JSONObject(prefs.getString("data", "{}") ?: "{}")
    private fun save() = prefs.edit().putString("data", d.toString()).apply()
    private fun obj(k: String): JSONObject = d.optJSONObject(k) ?: JSONObject().also { d.put(k, it) }

    var level: Int
        get() = d.optInt("level", 1)
        set(v) { d.put("level", v); save() }
    var sessions: Int
        get() = d.optInt("sessions", 0)
        set(v) { d.put("sessions", v); save() }

    fun mastery(topic: String) = obj("mastery").optInt(topic, 0)
    fun addMastery(topic: String, delta: Int) { obj("mastery").put(topic, (mastery(topic) + delta).coerceAtLeast(0)); save() }

    fun mistake(key: String) { val o = obj("mistakes"); o.put(key, o.optInt(key, 0) + 1); save() }
    fun topMistakes(n: Int = 3): List<String> { val o = obj("mistakes"); return o.keys().asSequence().sortedByDescending { o.optInt(it) }.take(n).toList() }

    // hard questions: id -> number of correct answers since it became hard (cleared after 2)
    fun markHard(id: String) { obj("hard").put(id, 0); save() }
    fun hardIds(): List<String> = obj("hard").keys().asSequence().toList()
    fun hardSuccess(id: String) {
        val o = obj("hard"); if (!o.has(id)) return
        val n = o.optInt(id) + 1
        if (n >= 2) o.remove(id) else o.put(id, n)
        save()
    }

    fun asked(id: String, day: String) { obj("asked").put(id, day); save() }
    fun askedOn(id: String): String = obj("asked").optString(id, "")

    fun addWords(text: String) {
        val o = obj("words")
        Regex("[a-zA-Z']+").findAll(text).forEach { val w = it.value.lowercase(); o.put(w, o.optInt(w, 0) + 1) }
        save()
    }
    fun wordCount() = obj("words").length()

    /** Adaptive level: 5 of last 6 correct -> level up, 2 or fewer -> level down. */
    fun record(ok: Boolean) {
        val r = (d.optString("recent", "") + if (ok) "1" else "0").takeLast(6)
        d.put("recent", r)
        if (r.length == 6) {
            val good = r.count { it == '1' }
            if (good >= 5 && level < 3) { level += 1; d.put("recent", "") }
            else if (good <= 2 && level > 1) { level -= 1; d.put("recent", "") }
        }
        save()
    }
}
