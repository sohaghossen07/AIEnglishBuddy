package com.aienglishbuddy

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Sync {
    fun loadExtra(ctx: Context): List<Question> {
        val f = File(ctx.filesDir, "topics.json")
        return if (f.exists()) Questions.fromJson(f.readText()) else emptyList()
    }

    /** Runs automatically as soon as the internet is available. */
    fun schedule(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("sync", ExistingWorkPolicy.KEEP, req)
    }
}

class SyncWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val url = BuildConfig.TOPICS_URL
        if (url.isBlank()) return Result.success()
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 15000
            val body = c.inputStream.bufferedReader().readText()
            if (Questions.fromJson(body).isNotEmpty()) File(applicationContext.filesDir, "topics.json").writeText(body)
            // TODO: upload/merge learning progress with your own server here. Local data is never overwritten.
            Result.success()
        } catch (e: Exception) { Result.retry() }
    }
}
