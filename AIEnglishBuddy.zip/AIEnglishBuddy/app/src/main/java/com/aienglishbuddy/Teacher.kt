package com.aienglishbuddy

data class Reply(val say: String, val stop: Boolean = false)

/**
 * Rule-based teacher engine. To use an offline LLM later (llama.cpp / MediaPipe LLM Inference),
 * replace the logic in reply() and keep the Reply contract.
 */
class Teacher(private val store: LearningStore, extra: List<Question>) {
    private enum class S { ASK, REPEAT, CREATE }

    private val all = Questions.builtIn + extra
    private var s = S.ASK
    private var cur: Question = all.first()
    private var target = ""
    private var fails = 0
    private var reps = 0
    private var asked = 0
    private var silent = 0
    private val today = java.time.LocalDate.now().toString()
    private val praise = listOf("Excellent!", "Very good!", "Well done!", "Great job!")

    fun start(): String {
        store.sessions = store.sessions + 1
        val intro = if (store.sessions == 1) "Hello! I am your English teacher. We will speak only English. Let's begin. "
        else "Welcome back! Let's practise. " + if (store.topMistakes(1).isNotEmpty()) "We will also revise your difficult grammar. " else ""
        return intro + nextQuestion()
    }

    fun closing() = "Time is up! Great work today. Your progress is saved. See you next time. Goodbye!"

    private fun nextQuestion(): String {
        asked++
        val hard = store.hardIds().filter { store.askedOn(it) != today }
        val revise = if (asked % 4 == 0 && hard.isNotEmpty()) all.firstOrNull { it.id == hard.random() } else null
        val chosen = revise
            ?: all.filter { it.level <= store.level && store.askedOn(it.id) != today }.minByOrNull { store.mastery(it.topic) }
            ?: all.random()
        cur = chosen; fails = 0; reps = 0; s = S.ASK
        store.asked(chosen.id, today)
        return (if (revise != null) "Let's revise a difficult question from before. " else "") + chosen.prompt
    }

    private fun currentPrompt() = when (s) {
        S.ASK -> cur.prompt
        S.REPEAT -> "Please repeat: $target"
        S.CREATE -> "Make your own new sentence."
    }

    private fun words(x: String) = Regex("[a-z']+").findAll(x.lowercase()).map { it.value }.toList()
    private fun similarity(a: String, b: String): Double {
        val ta = words(a); val tb = words(b).toSet()
        return if (ta.isEmpty()) 0.0 else ta.count { it in tb }.toDouble() / ta.size
    }

    private fun teach(): Reply {
        fails++
        store.markHard(cur.id); store.record(false)
        if (fails >= 3) return Reply("Let's come back to this later. " + nextQuestion())
        s = S.ASK
        return Reply(
            if (fails == 1) "That's okay. ${cur.explain} For example: ${cur.example} Now, an easier question. ${cur.easy}"
            else "Let me teach it in a different way. ${cur.alt} Now try again. ${cur.easy}"
        )
    }

    fun reply(text: String?, confidence: Float = -1f): Reply {
        if (text.isNullOrBlank()) {
            silent++
            return if (silent >= 3) Reply("I cannot hear you now. Tap the microphone when you are ready. Goodbye!", true)
            else Reply("I did not hear you. Please try again. " + currentPrompt())
        }
        silent = 0
        val t = text.trim()
        store.addWords(t)
        if (confidence in 0f..0.45f) {
            store.mistake("pronunciation")
            return Reply("I could not understand you clearly. Please say it again, slowly.")
        }
        val low = t.lowercase()
        if (listOf("don't know", "dont know", "do not know", "no idea", "don't understand", "not sure").any { low.contains(it) }) return teach()

        return when (s) {
            S.REPEAT -> {
                if (similarity(target, t) >= 0.7) { s = S.CREATE; Reply("Great! That is correct now. Next, make your own new sentence using the same idea.") }
                else if (++reps >= 2) { store.markHard(cur.id); Reply("Let's practise this again later. " + nextQuestion()) }
                else Reply("Almost. Listen again. $target. Please repeat.")
            }
            S.CREATE -> {
                val issue = Grammar.check(t)
                store.addMastery(cur.topic, 1)
                if (issue != null) { store.mistake(issue.key); store.record(false); Reply("Good try. ${issue.why} Better: ${issue.fixed}. Let's move on. " + nextQuestion()) }
                else { store.record(true); Reply("${praise.random()} That was a perfect new sentence. " + nextQuestion()) }
            }
            S.ASK -> {
                val issue = Grammar.check(t)
                if (words(t).size < 3) {
                    fails++
                    if (fails >= 3) Reply("Let's try another one. " + nextQuestion())
                    else Reply("Please answer with a full sentence. For example: ${cur.example}")
                } else if (issue != null) {
                    store.mistake(issue.key); store.markHard(cur.id); store.record(false)
                    target = issue.fixed; s = S.REPEAT; reps = 0
                    Reply("Good try. ${issue.why} The correct sentence is: ${issue.fixed}. Please repeat it.")
                } else {
                    store.addMastery(cur.topic, 1); store.hardSuccess(cur.id); store.record(true)
                    Reply("${praise.random()} " + nextQuestion())
                }
            }
        }
    }
}
