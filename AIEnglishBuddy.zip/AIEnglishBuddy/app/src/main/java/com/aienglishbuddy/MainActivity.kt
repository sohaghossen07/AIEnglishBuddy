package com.aienglishbuddy

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Button
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var store: LearningStore
    private lateinit var teacher: Teacher
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var timer: CountDownTimer? = null
    private var active = false
    private var ttsReady = false
    private var stopAfterSpeech = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var timerView: TextView
    private lateinit var statusView: TextView
    private lateinit var mic: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        timerView = findViewById(R.id.timer); statusView = findViewById(R.id.status); mic = findViewById(R.id.mic)
        store = LearningStore(this)
        tts = TextToSpeech(this, this)
        mic.setOnClickListener { if (active) endSession() else begin() }
        Sync.schedule(this)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) { statusView.text = "Text-to-speech is not available"; return }
        tts.language = Locale.US
        tts.voices?.firstOrNull { it.locale.language == "en" && !it.isNetworkConnectionRequired }?.let { tts.voice = it }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { runOnUiThread { afterSpeech() } }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { runOnUiThread { afterSpeech() } }
        })
        ttsReady = true
    }

    private fun afterSpeech() {
        if (!active) return
        if (stopAfterSpeech) endSession() else listen()
    }

    private fun begin() {
        if (!ttsReady) { statusView.text = "Please wait, voice is loading"; return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { statusView.text = "Speech recognition is not available"; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        teacher = Teacher(store, Sync.loadExtra(this))
        active = true; stopAfterSpeech = false
        mic.text = "⏹ Stop"
        timer = object : CountDownTimer(30 * 60 * 1000L, 1000L) {
            override fun onTick(ms: Long) { val s = ms / 1000; timerView.text = "%02d:%02d".format(s / 60, s % 60) }
            override fun onFinish() { timerView.text = "00:00"; recognizer?.cancel(); say(teacher.closing(), true) }
        }.start()
        say(teacher.start())
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (res.firstOrNull() == PackageManager.PERMISSION_GRANTED) begin() else statusView.text = "Microphone permission is needed"
    }

    private fun say(text: String, stop: Boolean = false) {
        stopAfterSpeech = stop
        statusView.text = "Teacher is speaking…"
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    private fun listen() {
        if (!active) return
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onResults(r: Bundle) {
                        val text = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        val conf = r.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)?.firstOrNull() ?: -1f
                        handle(text, conf)
                    }
                    override fun onError(e: Int) {
                        if (!active) return
                        if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) handler.postDelayed({ listen() }, 500) else handle(null, -1f)
                    }
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(p: Bundle?) {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                })
            }
        }
        statusView.text = "Listening… speak English"
        recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        })
    }

    private fun handle(text: String?, conf: Float) {
        if (!active) return
        val r = teacher.reply(text, conf)
        say(r.say, r.stop)
    }

    private fun endSession() {
        active = false
        timer?.cancel(); tts.stop(); recognizer?.cancel()
        mic.text = "🎤 Start"; statusView.text = "Session saved. Tap to start again"; timerView.text = "30:00"
    }

    override fun onDestroy() {
        active = false
        recognizer?.destroy(); tts.shutdown(); timer?.cancel()
        super.onDestroy()
    }
}
