package com.aienglishbuddy

import org.json.JSONArray

data class Question(
    val id: String, val topic: String, val level: Int,
    val prompt: String, val explain: String, val example: String,
    val easy: String, val alt: String
)

object Questions {
    private fun q(id: String, topic: String, lv: Int, prompt: String, explain: String, example: String, easy: String, alt: String) =
        Question(id, topic, lv, prompt, explain, example, easy, alt)

    val builtIn = listOf(
        q("dl1", "Daily Life", 1, "What do you do every morning? Please answer in a full sentence.",
            "After I, we use the simple verb.", "I wake up at six. I drink tea.",
            "What time do you wake up? Say: I wake up at, and then the time.", "Listen: I wake up at seven. Now say your own time."),
        q("dl2", "Daily Life", 2, "Tell me about your best friend. What does he or she do?",
            "With he, she or it, the verb takes s at the end.", "She works in a shop. He plays football.",
            "Say one sentence: My friend is a student, or my friend works in a shop.", "Think of he or she plus verb plus s. She likes music. Now try."),
        q("dl3", "Daily Life", 3, "Describe what you did yesterday.",
            "For the past, many verbs end with ed. Some are irregular, like went and ate.", "Yesterday I went to the market and bought rice.",
            "What did you eat yesterday? Say: Yesterday I ate...", "Past tense: go becomes went, eat becomes ate. Say: Yesterday I went to the market."),
        q("sh1", "Shopping", 1, "What do you want to buy today? Say a full sentence.",
            "We say I want to buy, and then the thing.", "I want to buy a shirt.",
            "Say: I want to buy, and then one thing.", "Listen: I want to buy bread. Now you say one thing."),
        q("sh2", "Shopping", 2, "You are in a shop. How do you ask for the price?",
            "A polite question is: How much is this?", "How much is this bag? How much are these shoes?",
            "Say: How much is this?", "Use is for one thing, and are for many things. How much are these?"),
        q("fd1", "Food and Cooking", 1, "What is your favourite food? Why do you like it?",
            "We say I like, then the food, then because, then the reason.", "I like rice because it is tasty.",
            "Say: I like, and then one food.", "Listen: I like fish. Now say your food."),
        q("fd2", "Food and Cooking", 2, "How do you cook your favourite food?",
            "To explain steps, use first, then, and finally.", "First I wash the rice. Then I boil it. Finally I add salt.",
            "Say one step: First I wash the rice.", "Use first, then, finally. Try with tea: First I boil water."),
        q("tr1", "Travelling", 1, "Where do you want to travel? Say a full sentence.",
            "We say I want to go to, and then the place.", "I want to go to Malaysia.",
            "Say: I want to go to, and a country.", "Listen: I want to go to Japan. Now say your country."),
        q("tr2", "Travelling", 2, "You are at the airport. How do you ask where gate five is?",
            "Polite questions start with Excuse me, or Could you tell me.", "Excuse me, where is gate five?",
            "Say: Excuse me, where is the bathroom?", "Start with Excuse me. Then where is, and the place."),
        q("fm1", "Friends and Family", 1, "Tell me about your family.",
            "We say I have, and then the number and the people.", "I have two brothers and one sister.",
            "How many brothers or sisters do you have? Say: I have...", "Listen: I have one brother. Now say yours."),
        q("jb2", "Jobs and Interviews", 2, "In an interview, how do you introduce yourself?",
            "Start with My name is, then your job or study, then your skills.", "My name is Rahim. I am a video editor. I am good at teamwork.",
            "Say: My name is, and your name.", "Three parts: name, job, skill. My name is Rahim. I am a student."),
        q("tc2", "Technology", 2, "How do you use your phone every day?",
            "Use the simple present for habits.", "I use my phone to watch videos and talk to my friends.",
            "Say: I use my phone to...", "Listen: I use my phone to take photos. Now say your use.")
    )

    fun fromJson(json: String): List<Question> = try {
        val a = JSONArray(json)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Question(o.getString("id"), o.getString("topic"), o.optInt("level", 1), o.getString("prompt"),
                o.optString("explain", ""), o.optString("example", ""), o.optString("easy", o.getString("prompt")),
                o.optString("alt", o.optString("explain", "")))
        }
    } catch (e: Exception) { emptyList() }
}
