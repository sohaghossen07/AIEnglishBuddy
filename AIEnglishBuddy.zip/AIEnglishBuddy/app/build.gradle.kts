plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.aienglishbuddy"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.aienglishbuddy"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // Put your own JSON file URL here to download new topics when online. Leave empty to skip.
        buildConfigField("String", "TOPICS_URL", "\"\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.work:work-runtime:2.9.0")
}
