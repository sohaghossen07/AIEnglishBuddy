#!/usr/bin/env bash
# Usage: ./setup_github.sh https://github.com/YOUR_NAME/AIEnglishBuddy.git
set -e
[ -z "$1" ] && { echo "Give your GitHub repo URL: ./setup_github.sh <repo-url>"; exit 1; }
git init -b main
git add .
git commit -m "AI English Buddy: first version"
git remote add origin "$1"
git push -u origin main
echo "Done! Open GitHub > Actions > Build APK > download the APK artifact."
